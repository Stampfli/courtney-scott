/************** Lightbox **************/

var lightbox = true;

/*********** Infinite Scroll **********/

var infinite_scroll = "scroll";

/******** Featured Posts Slider ********/

var slider_auto_slide = false; // slide automatically, true or false
var slider_pagination = false; //display slider pagination, true or false
var slider_nav = false; //display slider navigation (the arrows), true or false
var slider_transition_speed = 500; //speed of transition, in milliseconds
var slider_image_timeout = 4000; //time between slide transitions, in milliseconds
var slider_pause = true; //pause on hover, true or false
var slider_keyboard = false; //control the slider using direction arrows (keyboard)

/************ Social Media ************/

var facebook_link = "https://www.facebook.com/pages/Beyond-Productions";
var twitter_link = "https://twitter.com/scottwork";
var google_plus_link = "https://plus.google.com/114581668914060681014/posts";
var vimeo_link = "https://vimeo.com/83712662";
var rss_link = true;
